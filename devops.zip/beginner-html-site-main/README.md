# Beginner HTML Site

This is a basic one-page website to help beginners learn the fundamentals of HTML.
You can follow this code while learning from the [HTML basics](https://developer.mozilla.org/en-US/Learn/Getting_started_with_the_web/HTML_basics) course.
